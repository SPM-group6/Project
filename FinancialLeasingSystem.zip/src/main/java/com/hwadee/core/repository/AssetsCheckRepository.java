
package com.hwadee.core.repository;

public interface AssetsCheckRepository {
}
